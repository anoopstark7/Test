# Stark: Play Integrity checker (liquid glass + shuriken UI)

1. Create a new empty GitHub repo.
2. Upload ALL files from this folder (keep the .github folder).
3. Open the repo's Actions tab, run "Build APK" (it also runs on every push).
4. When it finishes, open the run and download the "Stark-APK" artifact, unzip it, and install the .apk.
Uninstall the original Play Integrity API Checker first (same app id, different signature).
