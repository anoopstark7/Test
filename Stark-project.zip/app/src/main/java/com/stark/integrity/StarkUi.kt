package com.stark.integrity

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Verdict { UNKNOWN, PASS, FAIL }

data class UiState(
    val results: List<Verdict> = List(3) { Verdict.UNKNOWN },
    val loading: Boolean = false,
    val error: String? = null
)

private val Orange = Color(0xFFFF8A1F)
private val PassC = Color(0xFF43E58F)
private val FailC = Color(0xFFFF6B7F)
private val UnkC = Color(0xFFFFC13D)
private val TITLES = listOf("Basic integrity", "Device integrity", "Strong integrity")

@Composable
fun StarkApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf(UiState()) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2600); splash = false }

    Box(Modifier.fillMaxSize()) {
        Backdrop()
        Main(state) {
            scope.launch {
                state = UiState(loading = true)
                IntegrityChecker(ctx).check()
                    .onSuccess { ok ->
                        state = UiState(results = VERDICT_KEYS.map { if (it in ok) Verdict.PASS else Verdict.FAIL })
                    }
                    .onFailure { state = UiState(error = it.message ?: "Check failed") }
            }
        }
        AnimatedVisibility(splash, exit = fadeOut(tween(700)) + scaleOut(tween(700), targetScale = 1.1f)) { Splash() }
    }
}

// Glass look: translucent gradient fill, bright specular top edge, light border.
fun Modifier.glass(radius: Int = 28): Modifier = composed {
    val shape = RoundedCornerShape(radius.dp)
    this
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(.24f), Color.White.copy(.07f))))
        .drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(Color.White.copy(.35f), Color.Transparent),
                    center = Offset(size.width * .2f, 0f), radius = size.width * .7f
                )
            )
        }
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.75f), Color.White.copy(.08f), Color.White.copy(.35f))), shape)
}

@Composable
fun Backdrop() {
    val t = rememberInfiniteTransition(label = "bd")
    val dx by t.animateFloat(0f, 80f, infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dx")
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.linearGradient(listOf(Color(0xFF2A1B5E), Color(0xFF7A2F6B), Color(0xFFFF7A1A)), Offset.Zero, Offset(size.width, size.height)))
            val r = size.width * .85f
            val c1 = Offset(size.width * .1f + dx, size.height * .12f)
            drawCircle(Brush.radialGradient(listOf(Color(0xCCFFD36B), Color.Transparent), c1, r), r, c1)
            val c2 = Offset(size.width * .95f - dx, size.height * .92f)
            drawCircle(Brush.radialGradient(listOf(Color(0xCC4D7CFF), Color.Transparent), c2, r), r, c2)
        }
        Shuriken(Color.White.copy(.07f), Modifier.size(420.dp).align(Alignment.CenterEnd).offset(x = 170.dp), spin = true, seconds = 40)
    }
}

@Composable
fun Shuriken(color: Color, modifier: Modifier = Modifier, spin: Boolean = false, seconds: Int = 3) {
    val t = rememberInfiniteTransition(label = "sh")
    val a by t.animateFloat(0f, 360f, infiniteRepeatable(tween(seconds * 1000, easing = LinearEasing)), label = "a")
    Canvas(modifier.graphicsLayer { rotationZ = if (spin) a else 0f }) {
        val s = size.minDimension / 100f
        val pts = listOf(50f to 2f, 62f to 38f, 98f to 50f, 62f to 62f, 50f to 98f, 38f to 62f, 2f to 50f, 38f to 38f)
        val p = Path().apply {
            fillType = PathFillType.EvenOdd
            moveTo(pts[0].first * s, pts[0].second * s)
            pts.drop(1).forEach { lineTo(it.first * s, it.second * s) }
            close()
            addOval(Rect(Offset(50f * s, 50f * s), 12f * s))
        }
        drawPath(p, color)
    }
}

@Composable
fun Splash() {
    Column(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF150D33), Color(0xFF3A1550), Color(0xFF7A2A10)))),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Shuriken(Color(0xFFFFB36B), Modifier.size(120.dp), spin = true, seconds = 6)
        Spacer(Modifier.height(22.dp))
        Text("STARK", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 10.sp)
        Spacer(Modifier.height(8.dp))
        Text("INTEGRITY CHECKER", color = Color.White.copy(.7f), fontSize = 13.sp, letterSpacing = 4.sp)
    }
}

@Composable
fun Main(state: UiState, onCheck: () -> Unit) {
    val passed = state.results.count { it == Verdict.PASS }
    val sweep by animateFloatAsState(passed / 3f * 360f, tween(800), label = "sw")
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().glass(24).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Shuriken(Orange, Modifier.size(34.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Stark", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Play Integrity checker", color = Color.White.copy(.7f), fontSize = 12.sp)
            }
        }
        Column(Modifier.fillMaxWidth().glass().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(136.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(8.dp)) {
                    drawArc(Color.White.copy(.25f), 0f, 360f, false, style = Stroke(22f))
                    drawArc(Orange, -90f, sweep, false, style = Stroke(22f, cap = StrokeCap.Round))
                }
                Text("$passed/3", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("Chakra level", color = Color.White.copy(.7f), fontSize = 13.sp)
        }
        state.results.forEachIndexed { i, v ->
            val c = when (v) { Verdict.PASS -> PassC; Verdict.FAIL -> FailC; Verdict.UNKNOWN -> UnkC }
            Row(Modifier.fillMaxWidth().glass(24).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Shuriken(c, Modifier.size(46.dp), spin = v == Verdict.PASS)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(TITLES[i], color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(VERDICT_KEYS[i], color = Color.White.copy(.65f), fontSize = 11.sp)
                }
                Text(
                    when (v) { Verdict.PASS -> "Passed"; Verdict.FAIL -> "Failed"; Verdict.UNKNOWN -> "Not checked" },
                    color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
            }
        }
        state.error?.let { Text(it, color = FailC, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().height(58.dp)
                .clip(RoundedCornerShape(50))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFD08A), Orange)))
                .border(1.dp, Color.White.copy(.7f), RoundedCornerShape(50))
                .clickable(enabled = !state.loading, onClick = onCheck),
            contentAlignment = Alignment.Center
        ) {
            if (state.loading) CircularProgressIndicator(Modifier.size(24.dp), color = Color(0xFF2A1200), strokeWidth = 2.5.dp)
            else Text("Run check", color = Color(0xFF2A1200), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
