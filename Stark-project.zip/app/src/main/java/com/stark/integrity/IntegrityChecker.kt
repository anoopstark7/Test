package com.stark.integrity

import android.content.Context
import android.util.Base64
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom

val VERDICT_KEYS = listOf("MEETS_BASIC_INTEGRITY", "MEETS_DEVICE_INTEGRITY", "MEETS_STRONG_INTEGRITY")

// The same decoder service the original app uses (it sends the token there and gets the verdict back).
private const val DECODE_URL = "https://integrity.1nikolas.dev/api/check?token="

class IntegrityChecker(private val context: Context) {
    suspend fun check(): Result<Set<String>> = runCatching {
        val nonceBytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val nonce = Base64.encodeToString(nonceBytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val token = IntegrityManagerFactory.create(context)
            .requestIntegrityToken(IntegrityTokenRequest.builder().setNonce(nonce).build())
            .await().token()
        val body = withContext(Dispatchers.IO) {
            val conn = URL(DECODE_URL + URLEncoder.encode(token, "UTF-8")).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            try {
                if (conn.responseCode !in 200..299) error("Server returned ${conn.responseCode}")
                conn.inputStream.bufferedReader().readText()
            } finally { conn.disconnect() }
        }
        VERDICT_KEYS.filter { body.contains("\"$it\"") }.toSet()
    }
}
